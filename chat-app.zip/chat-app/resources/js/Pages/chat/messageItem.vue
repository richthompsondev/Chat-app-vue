<template>
    <div> {{message}} </div>
</template>

<script>
export default {
    props:[
        'messages'
    ]

}
</script>
